import React from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
} from "react-native";
import { Button } from "~/components/ui/button";
import { Card } from "~/components/ui/card";
import { Separator } from "~/components/ui/separator";
import {
  BottomSheetModal,
  BottomSheetView,
  BottomSheetHandle,
} from "~/components/ui/bottom-sheet";
import { useSharedValue } from "react-native-reanimated";

const candidatesData = [
  {
    id: "1",
    name: "John Doe",
    votes: 150,
    image: "https://i.pravatar.cc/150?img=1",
  },
  {
    id: "2",
    name: "Jane Smith",
    votes: 120,
    image: "https://i.pravatar.cc/150?img=2",
  },
  {
    id: "3",
    name: "Bob Johnson",
    votes: 100,
    image: "https://i.pravatar.cc/150?img=3",
  },
];

const votersData = [
  { id: "1", name: "Alice", votedFor: "John Doe", time: "2 minutes ago" },
  { id: "2", name: "Charlie", votedFor: "Jane Smith", time: "5 minutes ago" },
  { id: "3", name: "David", votedFor: "Bob Johnson", time: "10 minutes ago" },
  { id: "4", name: "Eva", votedFor: "John Doe", time: "15 minutes ago" },
  { id: "5", name: "Frank", votedFor: "Jane Smith", time: "20 minutes ago" },
  { id: "6", name: "Grace", votedFor: "Bob Johnson", time: "25 minutes ago" },
  { id: "7", name: "Henry", votedFor: "John Doe", time: "30 minutes ago" },
  { id: "8", name: "Ivy", votedFor: "Jane Smith", time: "35 minutes ago" },
];

export default function indexEvent() {
  const [candidates, setCandidates] = React.useState(candidatesData);
  const [voters, setVoters] = React.useState(votersData);
  // const bottomSheetRef = React.useRef<BottomSheet>(null);

  // BOTTOM SHEET
  const bottomSheetModalRef = React.useRef<BottomSheetModal>(null);

  // bottomSheetModalRef
  console.log({ bottomSheetModalRef });

  // variables
  const snapPoints = React.useMemo(() => [600, "20%", "50%", "70%", "95%"], []);

  // Tambahkan ini di bawah deklarasi snapPoints
  const animatedIndex = useSharedValue(1);
  const animatedPosition = useSharedValue(0);

  // callbacks
  const handlePresentModalPress = React.useCallback(() => {
    bottomSheetModalRef.current?.present();
  }, []);

  const handleSheetChanges = React.useCallback((index: number) => {
    console.log("handleSheetChanges", index);
  }, []);
  // BOTTOM SHEET

  const renderCandidateItem = ({
    item,
    index,
  }: {
    item: any;
    index: number;
  }) => (
    <>
      {/* <Dialog>
        <DialogTrigger asChild> */}
      <TouchableOpacity onPress={handlePresentModalPress}>
        <Card className="flex-row items-center justify-between p-4 mb-2 rounded-lg shadow dark:border-gray-600">
          <View className="flex-row items-center">
            <Text className="text-2xl font-bold mr-4 dark:text-gray-100">
              {index + 1}
            </Text>
            <Image
              source={{ uri: item.image }}
              className="w-12 h-12 rounded-full mr-4"
            />
            <View>
              <Text className="font-semibold dark:text-gray-100">
                {item.name}
              </Text>
              <Text className="text-gray-600 dark:text-gray-200">
                {item.votes} votes
              </Text>
            </View>
          </View>
          <Button
            onPress={() => {
              const updatedCandidates = candidates.map((c) =>
                c.id === item.id ? { ...c, votes: c.votes + 1 } : c
              );
              setCandidates(
                updatedCandidates.sort((a, b) => b.votes - a.votes)
              );
              setVoters([
                {
                  id: Date.now().toString(),
                  name: "You",
                  votedFor: item.name,
                  time: "Just now",
                },
                ...voters,
              ]);
            }}
          >
            <Text className="text-white font-semibold dark:text-gray-800">
              Vote
            </Text>
          </Button>
        </Card>
      </TouchableOpacity>
      <BottomSheetModal
        ref={bottomSheetModalRef}
        index={1}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}
        handleComponent={() => (
          <BottomSheetHandle
            className="bg-green-300 mt-2"
            animatedIndex={animatedIndex}
            animatedPosition={animatedPosition}
          />
        )}
      >
        <BottomSheetView className="flex-1 items-center dark:bg-neutral-800">
          <View className="grid grid-cols-2 gap-2 mb-2 px-4 py-2">
            <View>
              <Text className="text-center font-semibold tracking-tight uppercase text-gray-500 text-lg dark:text-gray-200">
                John & Voxy
              </Text>
            </View>
            <Separator className="my-2 dark:border-gray-600" />
            <View>
              <Text className="font-semibold tracking-tight uppercase text-gray-500 dark:text-gray-400">
                Visi
              </Text>
              <Text className="dark:text-gray-100">
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab
                illo expedita ea unde sit? Corporis odit magni ut in fuga.
              </Text>
            </View>
            <View>
              <Text className="font-semibold tracking-tight uppercase text-gray-500 dark:text-gray-400">
                Misi
              </Text>
              <Text className="dark:text-gray-100">
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab
                illo expedita ea unde sit? Corporis odit magni ut in fuga.
              </Text>
            </View>
            <View>
              <Text className="font-semibold tracking-tight uppercase text-gray-500 dark:text-gray-400">
                Deskripsi
              </Text>
              <Text className="dark:text-gray-100">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Est ab
                minus officia ex repudiandae enim velit iusto facilis nisi,
                minima atque quidem earum animi ipsum error obcaecati qui
                necessitatibus pariatur? Placeat sapiente reiciendis quaerat
                distinctio, esse modi? Voluptate, inventore modi.
              </Text>
              <Text className="dark:text-gray-100">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Suscipit, molestiae perspiciatis quisquam, sequi pariatur
                distinctio accusamus eum perferendis quibusdam totam blanditiis
                excepturi odio nobis maxime optio. Tempora, ducimus! Eius nemo
                vero explicabo quasi autem maiores, reprehenderit veritatis
                aspernatur obcaecati suscipit omnis? Minus sunt maxime
                necessitatibus earum, alias aliquam sapiente eum deleniti nulla
                est tempore accusantium molestiae, dolorum dolor aliquid
                mollitia magnam quas quia dicta. Enim tenetur eligendi eos
                praesentium magnam et quam iure! Sit adipisci suscipit eaque
                minus consequuntur inventore, exercitationem provident corporis
                libero animi asperiores soluta velit voluptas praesentium odio
                quod commodi ab illo. Commodi consectetur officiis impedit
                saepe!
              </Text>
            </View>
          </View>
        </BottomSheetView>
      </BottomSheetModal>
      {/* </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <DialogClose asChild>
              <Button>
                <Text className="text-white dark:text-gray-800">OK</Text>
              </Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog> */}
    </>
  );

  const renderVoterItem = ({ item }: { item: any }) => {
    const name = item.name;
    const hiddenName = name
      .split("")
      .map((char: string, index: number) =>
        index === 0 || index === name.length - 1 ? char : "*"
      )
      .join("");
    return (
      <Card className="flex-row items-center justify-between p-4 mb-2 rounded-lg dark:border-gray-600">
        <View>
          <Text className="font-semibold dark:text-gray-100">{hiddenName}</Text>
          <Text className="text-gray-600 dark:text-gray-400">
            Voted for {item.votedFor}
          </Text>
        </View>
        <Text className="text-sm text-gray-500">{item.time}</Text>
      </Card>
    );
  };

  return (
    <SafeAreaView className="flex-1">
      <ScrollView className="flex-1">
        <View className="p-4">
          <Text className="text-xl font-semibold tracking-tight mb-4 dark:text-gray-100">
            Candidate
          </Text>
          {/* Render candidates manually instead of using FlatList */}
          {candidates.map((item, index) => (
            <React.Fragment key={item.id}>
              {renderCandidateItem({ item, index })}
            </React.Fragment>
          ))}

          <Text className="text-xl font-semibold tracking-tight mb-4 mt-6 dark:text-gray-100">
            Recent Votes
          </Text>
          {/* Render voters manually instead of using FlatList */}
          {voters.map((item) => (
            <React.Fragment key={item.id}>
              {renderVoterItem({ item })}
            </React.Fragment>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
